# pictures-manage

1、该项目除了数据库之外的全部文件已打包放在`picsmanage.zip`压缩包中，数据库导出文件也已经放在这个仓库中：`picsmanage.sql`;
<br><br>
